const express = require('express');
const bodyParser = require('body-parser');
const { MongoClient } = require('mongodb');
const cors = require('cors');

const app = express();
const port = 5000;

app.use(bodyParser.json());
app.use(cors());

const url = 'mongodb://localhost:27017';
const dbName = 'quiz_db';
const collectionName = 'answers';

MongoClient.connect(url => {
  if (err) return console.log(err);
  console.log("Connected successfully to server");

  const db = client.db(dbName);
  const collection = db.collection(collectionName);

  app.post('/api/answers', (req, res) => {
    const answers = req.body;
    collection.insertOne(answers, (err, result) => {
      if (err) {
        console.log(err);
        return res.status(500).send('Failed to insert answer into MongoDB');
      }
      console.log("Inserted answer into MongoDB");
      res.status(200).json(result.ops[0]);
    });
  });

  app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
});
