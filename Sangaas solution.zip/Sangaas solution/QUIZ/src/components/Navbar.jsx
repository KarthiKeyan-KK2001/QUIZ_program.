import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import './Navbar.css';

export const Navbar = () => {
  const [menuOpen, setMenuOut] = useState(false);

  return (
    <nav>
      <Link to='/WhyThis' className='title'> WhyThis</Link>
      <div className='menu' onClick={() => setMenuOut(!menuOpen)}>
        <span></span>
        <span></span>
        <span></span>
      </div>
      <ul className={menuOpen ? "open" : ""}>
        <li>
          <NavLink to='/' activeClassName="active">Home</NavLink>
        </li>
        <li>
          <NavLink to='/Python' activeClassName="active">Python</NavLink>
        </li>
        <li>
          <NavLink to='/Java' activeClassName="active">JAVA</NavLink>
        </li>
        <li>
          <NavLink to='/FrontEnd' activeClassName="active">FrontEnd</NavLink>
        </li>
      </ul>
    </nav>
  );
};
