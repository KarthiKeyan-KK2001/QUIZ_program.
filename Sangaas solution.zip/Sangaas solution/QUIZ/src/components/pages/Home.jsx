import React from 'react'

export const Home = () => {
  return <div>
    
<h1>HOME PAGE</h1>


  </div>;
};
