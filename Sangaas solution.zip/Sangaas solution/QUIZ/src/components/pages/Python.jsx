// import React from 'react'

// export const Python = () => {
//   return  (
//     <div className="quiz-container">
//       <h2>This is FRONT END</h2>

//       <div className="question">
//         <h3>Question 1: What does CSS stand for  </h3>
//         <div className="options">
//           <label>
//             <input type="radio" name="q1" value="Creative Style Sheets" />
//             Creative Style Sheets
//           </label>
//           <label>
//             <input type="radio" name="q1" value="Cascading Style Sheets" />
//             Cascading Style Sheets
//           </label>
//           <label>
//             <input type="radio" name="q1" value="Computer Style Sheets" />
//             Computer Style Sheets
//           </label>
//           <label>
//             <input type="radio" name="q1" value="Colorful Style Sheets" />
//             Colorful Style Sheets
//           </label>
//         </div>
//       </div>

      
//       <div className="question">
//         <h3>Question 2: Which HTML tag is used to define an unordered list?</h3>
//         <div className="options">
//           <label>
//             <input type="radio" name="q2" value="<ol>" />
//             ol
//           </label>
//           <label>
//             <input type="radio" name="q2" value="<ul>" />
//             ul
//           </label>
//           <label>
//             <input type="radio" name="q2" value="" />
//             list
//           </label>
//           <label>
//             <input type="radio" name="q2" value="<li>" />
//             li
//           </label>
//         </div>
//       </div>
//       <div className="question">
//         <h3>Question 3: Which CSS property is used to control the text size of an element?</h3>
//         <div className="options">
//           <label>
//             <input type="radio" name="q4" value=" font-style" />
//             font-style
//           </label>
//           <label>
//             <input type="radio" name="q4" value="" />
//             text-size
//           </label>
//           <label>
//             <input type="radio" name="q4" value="" />
//             font-size
//           </label>
//           <label>
//             <input type="radio" name="q4" value="text-style" />
//             text-style
//           </label>
//         </div>
//       </div>
//       <div className="question">
//         <h3>Question 4: In JavaScript, which method is used to stop the execution of a function immediately?</h3>
//         <div className="options">
//           <label>
//             <input type="radio" name="q3" value="return" />
//             return
//           </label>
//           <label>
//             <input type="radio" name="q3" value="break" />
//             break
//           </label>
//           <label>
//             <input type="radio" name="q3" value="continue" />
//             continue
//           </label>
//           <label>
//             <input type="radio" name="q3" value="stop" />
//             stop
//           </label>
//         </div>
//       </div>

//       <button className="submit-button">Submit</button>
//     </div>
//   );
// };





























// import React, { useState } from 'react';
// import './FrontEnd.css';

// export const Python = () => {
//   const [answers, setAnswers] = useState({
//     q1: '',
//     q2: '',
//     q3: '',
//     q4: ''
//   });

//   const correctAnswers = {
//     q1: 'Cascading Style Sheets',
//     q2: '<ul>',
//     q3: 'return',
//     q4: 'font-size'
//   };

//   const [showResults, setShowResults] = useState(false);

//   const handleInputChange = (e) => {
//     const { name, value } = e.target;
//     setAnswers({ ...answers, [name]: value });
//   };

//   const handleSubmit = async () => {
//     setShowResults(true);
//     try {
//       console.log('Correct Answers to be stored:', correctAnswers); // Debugging
//       const response = await fetch('/api/correct-answers', {
//         method: 'POST',
//         headers: {
//           'Content-Type': 'application/json',
//         },
//         body: JSON.stringify(correctAnswers),
//       });
//       if (response.ok) {
//         console.log('Correct answers stored successfully!');
//       } else {
//         console.error('Failed to store correct answers');
//       }
//     } catch (error) {
//       console.error('Error storing correct answers:', error);
//     }
//   };

//   const calculateScore = () => {
//     let score = 0;
//     Object.keys(answers).forEach((question) => {
//       if (answers[question] === correctAnswers[question]) {
//         score++;
//       }
//     });
//     return score;
//   };

//   const score = calculateScore();
//   const totalQuestions = Object.keys(answers).length;

//   return (
//     <div className="quiz-container">
//       <h2>Front End Quiz</h2>

//       <div className="question">
//         <h3>Question 1: What does CSS stand for?</h3>
//         <div className="options">
//           <label>
//             <input type="radio" name="q1" value="Creative Style Sheets" onChange={handleInputChange} />
//             Creative Style Sheets
//           </label>
//           <label>
//             <input type="radio" name="q1" value="Cascading Style Sheets" onChange={handleInputChange} />
//             Cascading Style Sheets
//           </label>
//           <label>
//             <input type="radio" name="q1" value="Computer Style Sheets" onChange={handleInputChange} />
//             Computer Style Sheets
//           </label>
//           <label>
//             <input type="radio" name="q1" value="Colorful Style Sheets" onChange={handleInputChange} />
//             Colorful Style Sheets
//           </label>
//         </div>
//       </div>

//       <div className="question">
//         <h3>Question 2: Which HTML tag is used to define an unordered list?</h3>
//         <div className="options">
//           <label>
//             <input type="radio" name="q2" value="<ol>" onChange={handleInputChange} />
//             ol
//           </label>
//           <label>
//             <input type="radio" name="q2" value="<ul>" onChange={handleInputChange} />
//             ul
//           </label>
//           <label>
//             <input type="radio" name="q2" value="" onChange={handleInputChange} />
//             list
//           </label>
//           <label>
//             <input type="radio" name="q2" value="<li>" onChange={handleInputChange} />
//             li
//           </label>
//         </div>
//       </div>

//       <div className="question">
//         <h3>Question 3: Which CSS property is used to control the text size of an element?</h3>
//         <div className="options">
//           <label>
//             <input type="radio" name="q4" value="font-style" onChange={handleInputChange} />
//             font-style
//           </label>
//           <label>
//             <input type="radio" name="q4" value="" onChange={handleInputChange} />
//             text-size
//           </label>
//           <label>
//             <input type="radio" name="q4" value="font-size" onChange={handleInputChange} />
//             font-size
//           </label>
//           <label>
//             <input type="radio" name="q4" value="text-style" onChange={handleInputChange} />
//             text-style
//           </label>
//         </div>
//       </div>

//       <div className="question">
//         <h3>Question 4: In JavaScript, which method is used to stop the execution of a function immediately?</h3>
//         <div className="options">
//           <label>
//             <input type="radio" name="q3" value="return" onChange={handleInputChange} />
//             return
//           </label>
//           <label>
//             <input type="radio" name="q3" value="break" onChange={handleInputChange} />
//             break
//           </label>
//           <label>
//             <input type="radio" name="q3" value="continue" onChange={handleInputChange} />
//             continue
//           </label>
//           <label>
//             <input type="radio" name="q3" value="stop" onChange={handleInputChange} />
//             stop
//           </label>
//         </div>
//       </div>

//       <button className="submit-button" onClick={handleSubmit}>Submit</button>

//       {showResults && (
//         <div className="results">
//           <h2>Quiz Results</h2>
//           <p>Correct Answers: {score}</p>
//           <p>Incorrect Answers: {totalQuestions - score}</p>
//         </div>
//       )}
//     </div>
//   );
// };
























// 





























import React, { useState } from 'react';
import './FrontEnd.css';

export const Python = () => {
  const [answers, setAnswers] = useState({
    q1: '',
    q2: '',
    q3: '',
    q4: ''
  });

  const correctAnswers = {
    q1: 'Cascading Style Sheets',
    q2: '<ul>',
    q3: 'return',
    q4: 'font-size'
  };

  const [showResults, setShowResults] = useState(false);
  const [submittedAnswers, setSubmittedAnswers] = useState(null);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setAnswers({ ...answers, [name]: value });
  };

  const handleSubmit = async () => {
    setShowResults(true);
    try {
      const response = await fetch('http://localhost:5000/api/answers', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(answers),
      });
      if (response.ok) {
        const data = await response.json();
        setSubmittedAnswers(data);
      } else {
        console.error('Failed to store answers in MongoDB');
      }
    } catch (error) {
      console.error('Error while submitting answers:', error);
    }
  };

  const calculateScore = () => {
    let score = 0;
    Object.keys(answers).forEach((question) => {
      if (answers[question] === correctAnswers[question]) {
        score++;
      }
    });
    return score;
  };

  const score = calculateScore();
  const totalQuestions = Object.keys(answers).length;

  return (
    <div className="quiz-container">
      <h2>Java Quiz</h2>

      <div className="question">
        <h3>Question 1: What does CSS stand for?</h3>
        <div className="options">
          <label>
            <input type="radio" name="q1" value="Creative Style Sheets" onChange={handleInputChange} />
            Creative Style Sheets
          </label>
          <label>
            <input type="radio" name="q1" value="Cascading Style Sheets" onChange={handleInputChange} />
            Cascading Style Sheets
          </label>
          <label>
            <input type="radio" name="q1" value="Computer Style Sheets" onChange={handleInputChange} />
            Computer Style Sheets
          </label>
          <label>
            <input type="radio" name="q1" value="Colorful Style Sheets" onChange={handleInputChange} />
            Colorful Style Sheets
          </label>
        </div>
      </div>

      <div className="question">
        <h3>Question 2: Which HTML tag is used to define an unordered list?</h3>
        <div className="options">
          <label>
            <input type="radio" name="q2" value="<ol>" onChange={handleInputChange} />
            ol
          </label>
          <label>
            <input type="radio" name="q2" value="<ul>" onChange={handleInputChange} />
            ul
          </label>
          <label>
            <input type="radio" name="q2" value="" onChange={handleInputChange} />
            list
          </label>
          <label>
            <input type="radio" name="q2" value="<li>" onChange={handleInputChange} />
            li
          </label>
        </div>
      </div>

      <div className="question">
        <h3>Question 3: Which CSS property is used to control the text size of an element?</h3>
        <div className="options">
          <label>
            <input type="radio" name="q4" value="font-style" onChange={handleInputChange} />
            font-style
          </label>
          <label>
            <input type="radio" name="q4" value="" onChange={handleInputChange} />
            text-size
          </label>
          <label>
            <input type="radio" name="q4" value="font-size" onChange={handleInputChange} />
            font-size
          </label>
          <label>
            <input type="radio" name="q4" value="text-style" onChange={handleInputChange} />
            text-style
          </label>
        </div>
      </div>

      <div className="question">
        <h3>Question 4: In JavaScript, which method is used to stop the execution of a function immediately?</h3>
        <div className="options">
          <label>
            <input type="radio" name="q3" value="return" onChange={handleInputChange} />
            return
          </label>
          <label>
            <input type="radio" name="q3" value="break" onChange={handleInputChange} />
            break
          </label>
          <label>
            <input type="radio" name="q3" value="continue" onChange={handleInputChange} />
            continue
          </label>
          <label>
            <input type="radio" name="q3" value="stop" onChange={handleInputChange} />
            stop
          </label>
        </div>
      </div>

      <button className="submit-button" onClick={handleSubmit}>Submit</button>

      {showResults && (
        <div className="results">
          <h2>Quiz Results</h2>
          <ul>
            {Object.keys(answers).map((question, index) => (
              <li key={index}>
                <strong>{`Question ${index + 1}:`}</strong> {answers[question]} (Your Answer) - {correctAnswers[question]} (Correct Answer) 
                {answers[question] === correctAnswers[question] ? ' - Correct' : ' - Incorrect'}
              </li>
            ))}
          </ul>
          <p>Score: {score} / {totalQuestions}</p>
          {submittedAnswers && (
            <p>Answers stored in MongoDB: {JSON.stringify(submittedAnswers)}</p>
          )}
        </div>
      )}
    </div>
  );
};






