import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { Navbar } from './components/Navbar';
// import { Services, Home } from './components/pages';
import {FrontEnd, Home, Java, Python } from './components/pages';
import { WhyThis } from './components/WhyThis';
import './App.css';

function App() {
  return (
    <Router>
      <div>
        <Navbar />
        <Routes>
          {/* <Route path="/services" element={<Services />} /> */}
          <Route path='/WhyThis' element={<WhyThis />} />
         <Route path='/' element={<Home />} />
         <Route path='/Python' element={<Python />} />
         <Route path='/FrontEnd' element={<FrontEnd />} />
         <Route path='/Java' element={<Java />} />
          {/* Add other routes here */}
        </Routes>
        
       
      </div>
    </Router>
  );
}

export default App;
